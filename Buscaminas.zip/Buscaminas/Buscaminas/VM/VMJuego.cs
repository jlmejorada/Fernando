﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BL;
using ENT;

namespace Buscaminas.VM
{
    public class VMJuego
    {
        #region ATRIBUTOS
        private int aciertos;

        private ENTPartida partidaActual;
        #endregion

        #region PROPIEDADES
        public int Aciertos { get { return aciertos; } set { aciertos = value; } }
        public ENTPartida PartidaActual { get { return partidaActual; } set { partidaActual = value; } }

        #endregion

        public VMJuego()
        {
            if (partidaActual == null)
            {
                partidaActual = new ENTPartida(1,BLManejadora.BLCuantasNumBombas(1), BLManejadora.BLCuantasDescubiertas(1));
            }
        }
    }
}
