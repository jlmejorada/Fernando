﻿using System.Collections.ObjectModel;

namespace ENT
{
    public class ENTPartida
    {
        #region ATRIBUTOS
        private int dificultad;

        private int numBombas;

        private int descubiertas;

        private ObservableCollection<ENTCasilla> tablero;

        private ENTCasilla seleccionada;
        #endregion

        #region PROPIEDADES
        public ENTCasilla Seleccionada { get { return seleccionada; } set { seleccionada.EstaRevelada = true; } }
        #endregion

        #region CONSTRUCTOR
        public ENTPartida(int dificultad, int numBombas, int descubiertas, int tamn)
        {
            this.dificultad = dificultad;
            this.numBombas = numBombas;
            this.descubiertas = descubiertas;
            for (int i = 0; i < tamn; i++)
            {
                this.tablero = tablero;
            }
            this.seleccionada = null;
        }
        #endregion
    }
}
